
-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `uname` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mno` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `cpassword` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `uname`, `email`, `mno`, `password`, `cpassword`) VALUES
(9, 'MANJEET KUMAR', 'manu', 'manjeetkumar14071996@gmail.com', '9336000032', '1234', '1234'),
(10, 'Sanjeev', 'Sanju', 'sanjeev123@gmail.com', '7894561032', '@123', '@123'),
(11, 'Sandeep', 'San', 'San123@gmail.com', '78645123102', '786@', '786@');
