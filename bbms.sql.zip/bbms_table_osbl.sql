
-- --------------------------------------------------------

--
-- Table structure for table `osbl`
--

CREATE TABLE `osbl` (
  `id` int(10) NOT NULL,
  `bname` varchar(5) DEFAULT NULL,
  `name` varchar(44) DEFAULT NULL,
  `mno` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `osbl`
--

INSERT INTO `osbl` (`id`, `bname`, `name`, `mno`) VALUES
(1, 'B+', 'Shashank', '9506032564'),
(2, 'AB-', 'Monu', '8604247347'),
(3, 'AB-', 'Atif', '9506032564'),
(4, 'O-', 'Manish', '9887665545'),
(5, 'A-', 'Priya', '9453567777'),
(6, 'A-', 'Priya', '9453567777');
