
-- --------------------------------------------------------

--
-- Table structure for table `cad`
--

CREATE TABLE `cad` (
  `id` int(10) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mno` varchar(20) DEFAULT NULL,
  `com` varchar(5) DEFAULT NULL,
  `wcom` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cad`
--

INSERT INTO `cad` (`id`, `name`, `email`, `mno`, `com`, `wcom`) VALUES
(1, 'Reena', 'reena123@gmail.com', '9506032564', 'No', NULL),
(2, 'Shivani', 'shivani123@gmail.com', '8876543223', 'Yes', 'Weakness'),
(3, 'Sunil', 'sunilt143@gnail.com', '7894561238', 'Yes', 'Headache'),
(4, 'Unnati', 'Unnati123@gmail.com', '789451239', 'No', NULL),
(5, 'MANJEET KUMAR', 'manjeetkumar14071996@gmail.com', '993600032', 'No', '');
