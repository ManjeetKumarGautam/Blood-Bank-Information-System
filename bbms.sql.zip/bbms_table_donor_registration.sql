
-- --------------------------------------------------------

--
-- Table structure for table `donor_registration`
--

CREATE TABLE `donor_registration` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `bgroup` varchar(4) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `mno` varchar(50) DEFAULT NULL,
  `lbdd` varchar(4) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `postalcode` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor_registration`
--

INSERT INTO `donor_registration` (`id`, `name`, `fname`, `address`, `city`, `country`, `bgroup`, `email`, `mno`, `lbdd`, `gender`, `postalcode`) VALUES
(1, 'Ritul', 'Rajveer singh', 'Bijnaur  ', 'lucknow', 'India', 'A+', 'ritulsinghyadav543@gmai.com', '9876547322', 'No', 'Female', 226002),
(2, 'Somya', 'Swyam', 'Chandrwal', 'lucknow', 'India', 'O+', 'somyasharama654@gmail.com', '8887659872', 'yes', 'Female', 226001),
(3, 'Virat', 'Giresh', 'Ashiyana', 'lucknow', 'India', 'AB+', 'viratkohli453@gmail.com', '8876667779', 'No', 'Male', 224568),
(4, 'Ankush', 'Lalu prasad', 'Shanti nagar', 'lucknow', 'India', 'AB-', 'ankushgupta765@gmail.com', '9997653392', 'yes', 'Male', 226003),
(5, 'Atin', 'Devraj', 'Bani', 'lucknow', 'India', 'B-', 'atinsahu756@gmail.com', '8876549032', 'No', 'Male', 226005),
(6, 'Priya', 'Lal gupta', 'Ashiyana', 'lucknow', 'India', 'A-', 'priyaraj444@gmail.com', '9453567777', 'yes', 'Female', 222283),
(7, 'Manjeet', 'Rajesh', 'Gate no-3', 'lucknow', 'India', 'B+', 'manjeetkumar554@gmail.com', '9987657678', 'No', 'Male', 226008),
(8, 'Piyush', 'Ramesh', 'Rajni khand', 'lucknow', 'India', 'O-', 'piyushtripathi765@gmail.com', '8876543223', 'yes', 'Male', 223546),
(9, 'sama singh', 'sanjeev', 'Awadh vihar colony\r\nNear to Amausi airport', 'LUCKNOW', ' india', 'A-', 'sam123@gmail.com', '9887655677', 'No', 'female', 226023),
(10, 'MANJEET KUMAR', 'rajesh kumar', 'Awadh vihar colony\r\nNear to Amausi airport', 'LUCKNOW', ' india', 'A+', 'manjeetkumar14071996@gmail.com', '9336000032', 'No', 'male', 226023);
