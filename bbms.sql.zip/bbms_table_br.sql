
-- --------------------------------------------------------

--
-- Table structure for table `br`
--

CREATE TABLE `br` (
  `id` int(10) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `bgroup` varchar(5) DEFAULT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `age` varchar(5) DEFAULT NULL,
  `mno` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `br`
--

INSERT INTO `br` (`id`, `name`, `bgroup`, `gender`, `age`, `mno`) VALUES
(2, 'Abhishek', 'B+', 'Male', '28', '9887646778'),
(3, 'Muskan', 'O-', 'Female', '23', '9887665545'),
(4, 'Kushagra', 'A+', 'Male', '20', '706818422'),
(5, 'Sonu', 'A-', 'Male', '25', '786453457'),
(6, 'MANJEET KUMAR', 'A+', 'male', '20', '936000032');
