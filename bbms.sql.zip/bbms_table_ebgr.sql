
-- --------------------------------------------------------

--
-- Table structure for table `ebgr`
--

CREATE TABLE `ebgr` (
  `id` int(10) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `fname` varchar(20) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `bgroup` varchar(20) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `mno` varchar(50) DEFAULT NULL,
  `ebg` varchar(5) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `postalcode` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ebgr`
--

INSERT INTO `ebgr` (`id`, `name`, `fname`, `address`, `city`, `country`, `bgroup`, `email`, `mno`, `ebg`, `gender`, `postalcode`) VALUES
(1, 'Mohit', 'Rajveer singh', 'Rajni Khand sharda Nagar', 'lucknow', 'India', 'B+', 'mohit123@gmail.com', '7864615333', 'A+', 'Male', '226008'),
(2, 'Harsh', 'Aditya Shukla', 'Ruchi Khand ', 'lucknow', 'India', 'O+', 'Shukla123@gmail.com', '8604247347', 'B-', 'Male', '226002'),
(3, 'rama yadav', 'sam', 'ashiyana', 'LUCKNOW', 'india', 'A-', 'ranjeetkumar14071996@gmail.com', '9336000032', 'O+', 'female', '226023');
